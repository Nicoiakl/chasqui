// Nyx5/1 — Libro: el ledger de doble entrada de una casa (dominio).
//
// El Libro es el segundo componente del sistema; el primero es el Correo. No tiene login propio:
// toda operación llega como un sobre firmado a `libro@<dominio>`, y la identidad del remitente ya
// viene verificada por la cadena de confianza del Correo. El Libro solo decide si la operación es
// válida (partes, estado, saldo) y ejecuta el asiento.
//
// Kernel: siete primitivas y nada más. Los contratos (contratos.js) se componen encima.
//   1. cotizar   -> no toca el libro: es un documento firmado por el vendedor (verifyQuote lo valida)
//   2. cobrar    -> transfer(de, a, monto)  con reparto de fee a la casa
//   3. retener   -> hold(de, escrow, monto)
//   4. liberar   -> release(escrow, a, monto) con fee
//   5. devolver  -> refund(escrow, a, monto) sin fee
//   6. repartir  -> post() con N líneas que suman cero (el fee de la casa es un reparto)
//   7. afianzar  -> hold() con condición de salida distinta (forfeit / release)
// Transversales: idempotencia (por id de sobre) y meta (contexto legible por máquina en cada asiento).
//
// Cuentas: `agente@dominio` (cualquier agente verificable, de esta casa o de otra), `casa@<dominio>`
// (la distribuidora: emite tokens, cobra fees; es la única que puede quedar en negativo) y
// `escrow:<contrato>` (fondos retenidos). Un asiento es una lista de líneas {cuenta, delta} que suman 0.
//
// ESCRITURAS: cada operación acumula sus escrituras en una transacción (this.tx) y el llamador la
// sella con commit() -> store.libroCommit(bundle). En FileStore el commit es secuencial (proceso
// único); en D1 es un batch atómico donde el número de asiento y el id de la op son claves únicas:
// dos operaciones concurrentes no pueden duplicar un asiento ni descuadrar los saldos — la segunda
// falla cerrado y el correo la reintenta.

import { signObject, verifyObject, canonical, sha256hex, uuid } from '../nucleo/crypto.js';
import { Resolver, parseAddress } from '../correo/resolver.js';
import { CONTRATOS } from './contratos.js';
import { LibroError } from './errores.js';
export { LibroError };

export const MEDIA = {
  op: 'application/nyx5.libro+json',
  cotizacion: 'application/nyx5.cotizacion+json',
  recibo: 'application/nyx5.recibo+json',
};

const iso = () => new Date().toISOString();

export class Libro {
  // feeBps: fee de la casa en basis points enteros (1000 = 10%). `feePct` sigue aceptándose
  // como azúcar (0.10 -> 1000) pero el cálculo es siempre entero: sin punto flotante en el dinero.
  constructor({ domain, store, keys, resolver, feeBps = null, feePct = null, welcome = 0, log = () => {} }) {
    this.domain = domain; this.store = store; this.keys = keys; this.resolver = resolver;
    this.feeBps = feeBps ?? (feePct != null ? Math.round(feePct * 10_000) : 1000);
    this.welcome = welcome; this.log = log;
    this.casa = `casa@${domain}`;
    this.address = `libro@${domain}`;
    this.tx = null; // transacción en curso: { state, asientos, contracts: Map, mandates: Map, op }
    this._lock = Promise.resolve(); // serializa las transacciones DENTRO de esta instancia; entre
                                    // procesos/isolates protegen las constraints de D1 (fallar cerrado)
  }
  _serial(fn) { const run = this._lock.then(fn); this._lock = run.catch(() => {}); return run; }
  get feePct() { return this.feeBps / 10_000; } // compat de lectura (tarjeta de libro@)

  // ---------- transacción ----------
  // El estado se lee UNA vez al abrir y no se vuelve a leer: si otra operación comete mientras
  // esta decide, el número de asiento que ésta reservó ya estará tomado y su commit falla cerrado.
  // Releer aquí sería el bug: dos cobros que leyeron el mismo mandato tomarían números distintos
  // y ambos entrarían, superando el tope.
  async _begin(concepto = 'control', refs = {}) {
    const base = await this.store.libroState();
    this.tx = { base, state: null, asientos: [], contracts: new Map(), mandates: new Map(), op: null, concepto, refs };
  }
  _bundle() {
    const t = this.tx;
    return { state: t.state, base: t.base, asientos: t.asientos, contracts: [...t.contracts.values()], mandates: [...t.mandates.values()], op: t.op };
  }
  async _commit() {
    const t = this.tx;
    // Una operación que muta el Libro sin mover dinero (revocar, entregar, sub-delegar) también
    // consume su número de asiento: es la única forma de que choque con quien corre en paralelo.
    // El asiento de control tiene lines vacío, así que sigue cuadrando en cero y queda auditable.
    if (!t.asientos.length && (t.contracts.size || t.mandates.size)) {
      const st = t.state ?? t.base;
      t.asientos.push(signObject({ id: uuid(), n: st.seq + 1, at: iso(), house: this.domain, concept: t.concepto, lines: [], meta: { kind: 'control' }, refs: t.refs }, this.keys));
      t.state = { seq: st.seq + 1, balances: st.balances };
    }
    const b = this._bundle();
    this.tx = null;
    await this.store.libroCommit(b);
    return b;
  }
  _abort() { this.tx = null; }
  // Lecturas que ven las escrituras pendientes de la propia transacción:
  async _state() { return this.tx ? (this.tx.state ?? this.tx.base) : await this.store.libroState(); }
  async getContract(id) { return this.tx?.contracts.get(id) ?? await this.store.libroGetContract(id); }
  putContract(c) { if (!this.tx) throw new LibroError(500, 'putContract fuera de transacción'); this.tx.contracts.set(c.id, c); }
  async getMandate(id) { return this.tx?.mandates.get(id) ?? await this.store.libroGetMandate(id); }
  putMandate(m) { if (!this.tx) throw new LibroError(500, 'putMandate fuera de transacción'); this.tx.mandates.set(m.id, m); }

  // ---------- consultas ----------
  get ops() { return Object.keys(CONTRATOS.ops); }
  async balance(account) { return (await this.store.libroState()).balances[account] || 0; }
  fee(amount) { return Math.floor((amount * this.feeBps) / 10_000); }
  async account(address) {
    const { contratoPublico } = await import('./contratos.js');
    const contracts = (await this.store.libroListContracts()).filter((c) => [c.seller, c.buyer, c.verifier, c.arbiter].includes(address)).map(contratoPublico);
    const mandates = (await this.store.libroListMandates()).filter((m) => m.grantor === address || m.grantee === address);
    return { account: address, balance: await this.balance(address), contracts, mandates };
  }
  async journal() { return this.store.libroJournal(); }

  // ---------- reputación = una consulta al libro ----------
  // No es un sistema de puntajes aparte: es lo que el libro ya sabe, contado. Por eso no se
  // puede inflar sin gastar. La defensa contra Sybil es de diseño: SOLO cuentan los contratos
  // cuyo asiento ya movió tokens (terminales). Un contrato abierto no dice nada de nadie.
  //
  // Estados terminales que cuentan, por tipo:
  //   spot   settled                      entrega pagada
  //   escrow released | refunded          entrega aceptada | devuelta
  //   bond   released | forfeited         afirmación sostenida | derribada
  static TERMINALES = { spot: ['settled'], escrow: ['released', 'refunded'], bond: ['released', 'forfeited'], metered: [] };

  async historial(address) {
    const todos = await this.store.libroListContracts();
    const mios = todos.filter((c) => [c.seller, c.buyer].includes(address));
    const cuenta = () => ({ n: 0, tokens: 0 });
    const h = {
      address, house: this.domain,
      vendiendo: { entregas_aceptadas: cuenta(), entregas_devueltas: cuenta(), ventas_directas: cuenta() },
      comprando: { encargos_liberados: cuenta(), encargos_devueltos: cuenta(), compras_directas: cuenta() },
      afirmando: { fianzas_sostenidas: cuenta(), fianzas_ejecutadas: cuenta(), fianzas_vigentes: cuenta() },
      avalando: { avales_sostenidos: cuenta(), avales_ejecutados: cuenta() },
      abiertos: cuenta(),
      desde: null, hasta: null, total_movido: 0,
    };
    const sumar = (c, monto) => { c.n += 1; c.tokens += monto; };
    for (const c of mios) {
      const terminal = (Libro.TERMINALES[c.kind] || []).includes(c.state);
      if (!terminal) { sumar(h.abiertos, 0); continue; }
      const monto = Number(c.amount) || 0;
      h.total_movido += monto;
      if (!h.desde || c.created < h.desde) h.desde = c.created;
      if (!h.hasta || c.created > h.hasta) h.hasta = c.created;
      if (c.kind === 'bond') {
        const grupo = c.vouchee ? h.avalando : h.afirmando;
        const sostenida = c.state === 'released';
        if (c.vouchee) sumar(sostenida ? grupo.avales_sostenidos : grupo.avales_ejecutados, monto);
        else sumar(sostenida ? grupo.fianzas_sostenidas : grupo.fianzas_ejecutadas, monto);
      } else if (c.seller === address) {
        if (c.kind === 'spot') sumar(h.vendiendo.ventas_directas, monto);
        else sumar(c.state === 'released' ? h.vendiendo.entregas_aceptadas : h.vendiendo.entregas_devueltas, monto);
      } else {
        if (c.kind === 'spot') sumar(h.comprando.compras_directas, monto);
        else sumar(c.state === 'released' ? h.comprando.encargos_liberados : h.comprando.encargos_devueltos, monto);
      }
    }
    // Fianzas todavía en pie: no son historial cumplido, pero sí tokens en juego ahora mismo.
    for (const c of mios) if (c.kind === 'bond' && c.state === 'posted' && c.seller === address) sumar(h.afirmando.fianzas_vigentes, Number(c.amount) || 0);
    // El resumen es lo que un agente lee para decidir en una línea; el detalle queda arriba.
    const entregadas = h.vendiendo.entregas_aceptadas.n + h.vendiendo.ventas_directas.n;
    const falladas = h.vendiendo.entregas_devueltas.n;
    const afirmaciones = h.afirmando.fianzas_sostenidas.n + h.afirmando.fianzas_ejecutadas.n;
    h.resumen = {
      entregas: entregadas, entregas_falladas: falladas,
      afirmaciones_con_fianza: afirmaciones, fianzas_perdidas: h.afirmando.fianzas_ejecutadas.n,
      tokens_en_juego_ahora: h.afirmando.fianzas_vigentes.tokens,
      total_movido: h.total_movido,
      // Sin historial no hay tasa: cero de cero no es 100%, es "todavía nada". Lo decimos así.
      cumplimiento: entregadas + falladas > 0 ? Number((entregadas / (entregadas + falladas)).toFixed(4)) : null,
      veracidad: afirmaciones > 0 ? Number((h.afirmando.fianzas_sostenidas.n / afirmaciones).toFixed(4)) : null,
    };
    return h;
  }


  // ---------- el kernel: un asiento ----------
  // lines: [{ account, delta }]; suma cero; nadie salvo la casa queda negativo.
  async post(concept, lines, meta = {}, refs = {}) {
    const total = lines.reduce((s, l) => s + l.delta, 0);
    if (total !== 0) throw new LibroError(500, `asiento descuadrado (${total})`);
    for (const l of lines) if (!Number.isInteger(l.delta)) throw new LibroError(400, 'los montos son enteros (tokens)');
    const state = await this._state();
    const next = { ...state.balances };
    for (const l of lines) {
      next[l.account] = (next[l.account] || 0) + l.delta;
      if (next[l.account] < 0 && l.account !== this.casa) throw new LibroError(402, `saldo insuficiente en ${l.account} (tiene ${state.balances[l.account] || 0}, necesita ${-l.delta})`);
    }
    const asiento = signObject({ id: uuid(), n: state.seq + 1, at: iso(), house: this.domain, concept, lines, meta, refs }, this.keys);
    if (this.tx) {
      this.tx.asientos.push(asiento);
      this.tx.state = { seq: state.seq + 1, balances: next };
    } else {
      // asiento suelto (topup administrativo): transacción propia, con el mismo candado
      await this.store.libroCommit({ base: state, state: { seq: state.seq + 1, balances: next }, asientos: [asiento], contracts: [], mandates: [], op: null });
    }
    return asiento;
  }

  // Primitivas construidas sobre post()
  async topup(account, amount, concept = 'carga', meta = {}) {
    parseAddress(account); this._amount(amount);
    const asentar = () => this.post(concept, [{ account: this.casa, delta: -amount }, { account, delta: amount }], { kind: 'topup', ...meta });
    return this.tx ? asentar() : this._serial(asentar);
  }
  // referrer opcional { address, share (bps) }: la comisión sale del monto (la recibe el vendedor),
  // no se suma al precio. El asiento pasa a 4 líneas y sigue cuadrando en cero.
  async transfer(from, to, amount, concept, meta = {}, refs = {}, referrer = null) {
    this._amount(amount);
    const fee = this.fee(amount);
    const com = referrer ? Math.floor((amount * referrer.share) / 10_000) : 0;
    const lines = [{ account: from, delta: -amount }, { account: to, delta: amount - fee - com }];
    if (fee) lines.push({ account: this.casa, delta: fee });
    if (com) lines.push({ account: referrer.address, delta: com });
    return this.post(concept, lines, { kind: 'charge', fee, ...(com ? { referrer: referrer.address, commission: com } : {}), ...meta }, refs);
  }
  async hold(from, contractId, amount, concept, meta = {}, refs = {}) {
    this._amount(amount);
    return this.post(concept, [{ account: from, delta: -amount }, { account: `escrow:${contractId}`, delta: amount }], { kind: 'hold', ...meta }, refs);
  }
  async release(contractId, to, amount, concept, meta = {}, refs = {}, referrer = null) {
    this._amount(amount);
    const fee = this.fee(amount);
    const com = referrer ? Math.floor((amount * referrer.share) / 10_000) : 0;
    const lines = [{ account: `escrow:${contractId}`, delta: -amount }, { account: to, delta: amount - fee - com }];
    if (fee) lines.push({ account: this.casa, delta: fee });
    if (com) lines.push({ account: referrer.address, delta: com });
    return this.post(concept, lines, { kind: 'release', fee, ...(com ? { referrer: referrer.address, commission: com } : {}), ...meta }, refs);
  }
  async refund(contractId, to, amount, concept, meta = {}, refs = {}) {
    this._amount(amount);
    return this.post(concept, [{ account: `escrow:${contractId}`, delta: -amount }, { account: to, delta: amount }], { kind: 'refund', ...meta }, refs);
  }
  _amount(a) { if (!Number.isInteger(a) || a <= 0) throw new LibroError(400, `monto inválido: ${a}`); }

  // ---------- cotizaciones: documentos firmados por el vendedor ----------
  // Una cotización viaja adentro de un sobre (cifrado si se quiere) y se presenta al Libro al aceptar.
  static buildQuote({ seller, buyer, house, contract = 'spot', price, concept, terms = {}, expires, arbiter = null, referrer = null }, sellerKeys) {
    if (!CONTRATOS[contract]?.quoteable) throw new LibroError(400, `contrato no cotizable: ${contract}`);
    if (arbiter) parseAddress(arbiter);
    // Comisión de referido: el vendedor firma en su cotización que le paga `share` (en basis points)
    // a quien trajo el trato. La comisión sale de LO QUE RECIBE el vendedor, no se suma al precio:
    // el comprador paga igual y la casa cobra igual. verifyQuote valida los límites al aceptar.
    if (referrer != null) {
      parseAddress(referrer.address);
      if (!Number.isInteger(referrer.share) || referrer.share <= 0) throw new LibroError(400, 'referrer.share debe ser un entero de basis points > 0');
    }
    return signObject({ tipo: 'cotizacion', id: uuid(), house, seller, buyer, contract, price, currency: 'tok', concept, terms, arbiter, referrer: referrer || undefined, issued: iso(), expires: expires || null }, sellerKeys);
  }
  async verifyQuote(q, buyer) {
    if (q?.tipo !== 'cotizacion' || !q.id || !q.seller || !q.signature) throw new LibroError(400, 'cotización malformada');
    // Solo tipos cotizables: una cotización firmada a mano con un kind inexistente (o no cotizable)
    // se rechaza limpio aquí, no explota en onAccept.
    if (!CONTRATOS[q.contract]?.quoteable) throw new LibroError(400, `contrato no cotizable: ${q.contract}`);
    if (q.house !== this.domain) throw new LibroError(400, `la cotización es para la casa ${q.house}, no ${this.domain}`);
    if (q.buyer !== buyer) throw new LibroError(403, 'la cotización no está dirigida a quien la acepta');
    if (q.expires && Date.parse(q.expires) < Date.now()) throw new LibroError(410, 'cotización vencida');
    if (q.arbiter) { try { parseAddress(q.arbiter); } catch { throw new LibroError(400, 'árbitro inválido en la cotización'); } }
    if (q.referrer != null) {
      try { parseAddress(q.referrer.address); } catch { throw new LibroError(400, 'referidor inválido en la cotización'); }
      if (!Number.isInteger(q.referrer.share) || q.referrer.share <= 0) throw new LibroError(400, 'referrer.share debe ser un entero de basis points > 0');
      // El fee de la casa y la comisión salen ambos del monto: juntos no pueden dejar al vendedor en negativo.
      if (this.feeBps + q.referrer.share > 10_000) throw new LibroError(400, `fee (${this.feeBps} bps) + comisión (${q.referrer.share} bps) supera el 100% del precio`);
      if (q.referrer.address === q.seller) throw new LibroError(400, 'el vendedor no puede ser su propio referidor');
    }
    this._amount(q.price);
    let card;
    try { card = await this.resolver.agentCardForKid(q.seller, q.signature.kid); } catch (e) { throw new LibroError(e.permanent ? 403 : 421, `no se pudo verificar al vendedor: ${e.message}`); }
    if (!Resolver.acceptedKids(card).includes(q.signature.kid) || !verifyObject(q, q.signature.kid)) throw new LibroError(403, 'firma de la cotización inválida');
    if (await this.store.libroFindContractByQuote(q.id)) throw new LibroError(409, 'cotización ya aceptada');
    return card;
  }

  // ---------- entrada: un sobre dirigido a libro@<dominio> ----------
  // Devuelve { ok, code, reason, result, recibos: [{ to: [...], body }] }. Idempotente por id de sobre.
  async handle(env, senderCard) {
    const prev = await this.store.libroGetOp(env.id);
    if (prev) return { ...prev, duplicate: true };
    if (!env.content || env.content.media !== MEDIA.op) return { ok: false, code: 400, reason: `el Libro solo acepta content.media = ${MEDIA.op} (sin cifrar: la casa debe leerlo)` };
    const body = env.content.body || {};
    const op = CONTRATOS.ops[body.op];
    if (!op) return { ok: false, code: 400, reason: `operación desconocida: ${body.op}. Válidas: ${Object.keys(CONTRATOS.ops).join(', ')}` };
    const ctx = { libro: this, env, from: env.from, body, senderCard, opHash: sha256hex(canonical(env)), scope: senderCard?.delegation?.scope || null };
    return this._serial(async () => {
      await this._begin(`op ${body.op}`, { op: env.id, op_sha256: ctx.opHash });
      let result;
      try { result = await op(ctx); }
      catch (e) {
        this._abort();
        if (e instanceof LibroError) return { ok: false, code: e.code, reason: e.message };
        throw e;
      }
      const out = { ok: true, code: 202, result: result.result, recibos: (result.recibos || []).map((r) => ({ ...r, body: { ...r.body, of: env.id, op: body.op, op_sha256: ctx.opHash, from: env.from } })), avisos: result.avisos || [] };
      this.tx.op = { id: env.id, result: out };
      try { await this._commit(); }
      catch (e) {
        // Conflicto de concurrencia (asiento u op duplicados en D1): la op ya corrió en paralelo.
        const cached = await this.store.libroGetOp(env.id);
        if (cached) return { ...cached, duplicate: true };
        throw e;
      }
      return out;
    });
  }

  // Estampilla: un sobre con `stamp` hacia un buzón con política `stamp` paga al llegar.
  // NO comete: devuelve { asiento, bundle } para que la estafeta lo selle JUNTO con el buzón y el
  // dedupe del sobre (inboundCommit) — así una reentrega jamás cobra la estampilla dos veces.
  async stamp(env, recipient, price) {
    const s = env.stamp;
    if (!s || s.house !== this.domain || !Number.isInteger(s.amount) || s.amount < price) throw new LibroError(402, `este buzón exige estampilla de ${price} tok en la casa ${this.domain} (campo stamp: {house, amount})`);
    return this._serial(async () => {
    await this._begin('estampilla', { envelope: env.id });
    try {
      const asiento = await this.transfer(env.from, recipient, s.amount, `estampilla ${env.from} -> ${recipient}`, { kind: 'stamp' }, { envelope: env.id, envelope_sha256: sha256hex(canonical(env)) });
      const bundle = this._bundle();
      this.tx = null;
      return { asiento, bundle };
    } catch (e) { this._abort(); throw e; }
    });
  }
}
